eval(function(p, a, c, k, e, r) {
	e = function(c) {
		return (c < a ? "" : e(parseInt(c / a))) + ((c = c % a) > 35 ? String.fromCharCode(c + 29) : c.toString(36))
	};
	if (!"".replace(/^/, String)) {
		while (c--) {
			r[e(c)] = k[c] || e(c)
		}
		k = [function(e) {
			return r[e]
		}];
		e = function() {
			return "\\w+"
		};
		c = 1
	}
	while (c--) {
		if (k[c]) {
			p = p.replace(new RegExp("\\b" + e(c) + "\\b", "g"), k[c])
		}
	}
	return p
}('!4(e){"42 41";6 i={1a:3,N:!1,K:1,B:10,D:"",q:"9",2u:!0,1x:"3Z",29:"3X",L:27,1C:!1,P:!1,1B:!0,1Q:3W,1J:!1,1S:!0,2J:"",35:"",1u:!1,1Y:!1,E:!1,2g:3T,24:1y,2l:10,H:!0,R:!1,25:5,1n:5,2W:"30",1N:!0,1U:!0,1X:!0,1r:40,1h:[],2y:4(){},2D:4(){},2G:4(){},2H:4(){},2a:4(){},2i:4(){}};e.3O.34=4(t){z(0===j.k)Q j;z(j.k>1)Q j.3L(4(){e(j).34(t)}),j;6 n={},l=e.3K(!0,{},i,t),s={},a=j;n.$3J=j,"19"===l.q&&(l.E=!1);6 o=a.1l(),r=e(1p).18(),d=1o,c=1o,f=0,h=0,u=!1,g=0,v="",p=0,m=l.E===!0?"1q":"18",M=l.E===!0?"1A-32":"1A-1b",b=0,T=0,C=0,S=0,x=1o,w="3I"1V 26.2A,y={};Q y.2c=4(){z(r=e(1p).18(),l.1h.k){6 i;z(l.N===!1&&(i=l.1a),r<l.1h[0].22)U(6 t=0;t<l.1h.k;t++)r<l.1h[t].22&&(d=l.1h[t].22,c=l.1h[t]);z("2R"!=2S c&&1o!==c)U(6 n 1V c.2h)c.2h.2X(n)&&(("2R"==2S s[n]||1o===s[n])&&(s[n]=l[n]),l[n]=c.2h[n]);z(!e.3H(s)&&r>l.1h[0].22)U(6 a 1V s)s.2X(a)&&(l[a]=s[a]);l.N===!1&&b>0&&C>0&&i!==l.1a&&(p=1I.3E(b/((C+l.B)*l.K)))}},y.20=4(){l.N===!1&&(C=(g-(l.1a*l.B-l.B))/l.1a)},y.1z=4(e){6 i=e===!0?v.8(".7-9").k:o.k;z(l.N===!1)h=i*(C+l.B);15{h=0;U(6 t=0;i>t;t++)h+=1i(o.J(t).18())+l.B}Q h%1!==0&&(h+=1),h},n={Y:4(){6 e=4(){U(6 e=["17","3D","3C","3B","3A","3x"],i=26.2A,t=0;t<e.k;t++)z(e[t]1V i.38)Q!0};Q l.2u&&e()?!0:!1},1J:4(){l.1J&&e(26).W("3w.3v",4(i){e(":3u").3t("3s, 3r")||(i.V?i.V():i.1D=!1,37===i.2V?(a.1F(),1e(x)):39===i.2V&&(a.1j(),1e(x)))})},1S:4(){l.1S&&(a.31(\'<1t 1c="7-14"><a 1c="7-2j">\'+l.2J+\'</a><a 1c="7-3a">\'+l.35+"</a></1t>"),l.N?y.1z(!1)<g&&v.8(".7-14").1K():f<=l.1a&&v.8(".7-14").1K(),v.8(".7-14 a").W("1L",4(i){Q i.V?i.V():i.1D=!1,"7-2j"===e(j).1M("1c")?a.1F():a.1j(),1e(x),!1}))},2v:4(){6 e=j;"19"===l.q&&(l.N=!1,l.1B=!1),l.1C&&(l.1B=!1),l.N&&(l.K=1,l.1a=1),l.P&&(l.K=1,l.1X=!1),l.2y.1g(j,a),y.2c(),a.D("1O-1P").3q("<1t 1c=\'7-9-3p "+l.D+"\'><1t 1c=\'7-9-2B\'></1t></1t>"),v=a.X(".7-9-2B"),l.1u===!0&&v.X().D("7-1u"),l.E?(v.X().D("E"),g=l.2g,v.A("1q",g+"G")):g=a.2F(),o.D("7-9"),l.P===!0&&"9"===l.q&&(y.20(),y.F=4(){z(y.1z(!0)>g){U(6 i=0,t=0,n=0;n<o.k&&(i+=1i(a.8(".7-9").J(n).18())+l.B,t++,!(i>=g+l.B));n++);6 s=l.N===!0?t:l.1a;z(s<a.8(".F.I").k)U(6 r=0;r<a.8(".F.I").k-s;r++)o.J(r).2b();z(s<a.8(".F.1b").k)U(6 d=o.k-1;d>o.k-1-a.8(".F.1b").k;d--)p--,o.J(d).2b();U(6 c=a.8(".F.1b").k;s>c;c++)a.8(".7-9").J(c).F().13("7-9").D("F 1b").3o(a),p++;U(6 f=a.8(".7-9").k-a.8(".F.I").k;f>a.8(".7-9").k-s;f--)a.8(".7-9").J(f-1).F().13("7-9").D("F I").3n(a);o=a.1l()}15 o.3l("F")&&(a.8(".F").2b(),e.1k(a,0))},y.F()),y.2e=4(){f=o.k,l.1u===!0&&l.E===!1&&(M="1A-I"),l.N===!1&&o.A(m,C+"G"),o.A(M,l.B+"G"),h=y.1z(!1),a.A(m,h+"G"),l.P===!0&&"9"===l.q&&u===!1&&(p=a.8(".F.I").k)},y.2f=4(){o=a.1l(),f=o.k},j.Y()&&v.D("3k-A"),y.2f(),"9"===l.q?(y.20(),y.2e(),l.P===!0&&(b=e.1w(),j.1k(a,b)),l.E===!1&&j.1s(a,!1,!0)):(j.1s(a,!0,!0),a.D("7-19"),j.Y()||o.3j(".O").A("3h","3g")),l.P===!0&&"9"===l.q?o.J(p).D("O"):o.1Z().D("O")},H:4(){6 e=j;z(y.2m=4(){S=(g-(l.2l*l.1n-l.1n))/l.2l;6 i=v.8(".7-9"),t=v.8(".7-9").k,n=0,s="",o=0;U(n=0;t>n;n++){"9"===l.q&&(l.N?o+=(1i(i.J(n).18())+l.B)*l.K:o=n*(C+l.B)*l.K);6 r=i.J(n*l.K).1M("3f-3e");z(s+=l.R===!0?\'<16 38="18:1y%;\'+m+":"+S+"G;"+M+":"+l.1n+\'G"><a 2p="#"><33 3d="\'+r+\'" /></a></16>\':\'<16><a 2p="#">\'+(n+1)+"</a></16>","9"===l.q&&o>=h-g-l.B){n+=1;6 d=2;l.N&&(s+=\'<16><a 2p="#">\'+(n+1)+"</a></16>",d=1),d>n?(s=1o,v.X().D("36-H")):v.X().13("36-H");2q}}6 c=v.X();z(c.8(".7-H").3c(s),!l.E&&l.R){6 f=v.X().8(".7-R");12(4(){e.1s(f,!1,!1)})}l.R===!0&&(l.E===!0&&c.8(".7-H").A("18",l.24+"G"),T=n*(l.1n+S)+.5,c.8(".7-H").A({3F:T+"G","17-1m":l.L+"1v"}),l.E===!0&&v.X().A("2Z-1b",l.24+l.25+"G"),c.8(".7-H").A(m,T+"G"));6 u=c.8(".7-H").8("16");u.1Z().D("O"),u.W("1L",4(){Q l.P===!0&&"9"===l.q?p+=u.2k(j)-c.8(".7-H").8("16.O").2k():p=u.2k(j),a.q(!1),l.R===!0&&e.1d(),1e(x),!1})},l.H){6 i="7-3i";l.R&&(i="7-R"),v.31(\'<2T 1c="7-H \'+i+\'"></2T>\');6 t=l.E?"1A-I":"1A-2Q";v.X().8(".7-H").A(t,l.25+"G"),y.2m()}12(4(){y.1T()},0)},1s:4(e,i,t){6 n=1o;n=t?e.1l(".7-9 ").1Z():e.1l().1Z();6 l=4(){z(0===p){6 t=n.1q(),l=0,s=t;i&&(t=0,l=1y*s/g),e.A({1q:t+"G","2Z-32":l+"%"})}};l(),n.8("33").3m(4(){12(4(){l()},1y)})},O:4(e,i){j.Y()&&"19"===l.q&&v.D("W");6 t=0;z(p*l.K<f){e.13("O"),j.Y()||"19"!==l.q||i!==!1||e.2L(l.L),t=i===!0?p:p*l.K;6 n,s;i===!0&&(n=e.k,s=n-1,t+1>=n&&(t=s)),l.P===!0&&"9"===l.q&&(t=i===!0?p-a.8(".F.I").k:p*l.K,i===!0&&(n=e.k,s=n-1,t+1==n?t=s:t+1>n&&(t=0))),j.Y()||"19"!==l.q||i!==!1||e.J(t).2K(l.L),e.J(t).D("O")}15 e.13("O"),e.J(e.k-1).D("O"),j.Y()||"19"!==l.q||i!==!1||(e.2L(l.L),e.J(t).2K(l.L))},1k:4(e,i){l.1u===!0&&(i=-i),j.Y()?e.A(l.E===!0?{1R:"1E(1f, "+-i+"G, 1f)","-2U-1R":"1E(1f, "+-i+"G, 1f)"}:{1R:"1E("+-i+"G, 1f, 1f)","-2U-1R":"1E("+-i+"G, 1f, 1f)"}):l.E===!0?e.A("2P","2O").2N({2Q:-i+"G"},l.L,l.29):e.A("2P","2O").2N({I:-i+"G"},l.L,l.29);6 t=v.X().8(".7-H").8("16");j.O(t,!0)},19:4(){j.O(o,!1);6 e=v.X().8(".7-H").8("16");j.O(e,!0)},9:4(){6 e=j;y.2M=4(){h>g&&(b=e.1w(),e.O(o,!1),b>h-g-l.B?b=h-g-l.B:0>b&&(b=0),e.1k(a,b),l.P===!0&&"9"===l.q&&(p>=f-a.8(".F.I").k/l.K&&e.23(a.8(".F.I").k),0===p&&e.23(v.8(".7-9").k)))},y.2M()},23:4(e){6 i=j;v.8(".7-14 a").D("2I"),12(4(){p=e,v.A("17-1m","2E"),b=i.1w(),i.O(o,!1),n.1k(a,b),12(4(){v.A("17-1m",l.L+"1v"),v.8(".7-14 a").13("2I")},3y)},l.L+1y)},1w:4(){6 e=0;z(l.N===!1)e=p*(C+l.B)*l.K;15{e=0;U(6 i=0;p>i;i++)e+=1i(o.J(i).18())+l.B}Q e},1d:4(){6 e;3z(l.2W){2n"I":e=0;2q;2n"30":e=g/2-S/2;2q;2n"1b":e=g-S}6 i=p-a.8(".F.I").k,t=v.X().8(".7-H");"9"===l.q&&l.P===!0&&(i>=t.1l().k?i=0:0>i&&(i=t.1l().k));6 n=i*(S+l.1n)-e;n+g>T&&(n=T-g-l.1n),0>n&&(n=0),j.1k(t,n)},1C:4(){l.1C&&(x=2C(4(){a.1j()},l.1Q))},1H:4(e,i){z(1e(x),v.A("17-1m","2E"),"9"===l.q){6 t=e-i,n=b-t;z(n>=h-g-l.B)z(l.1X===!1)n=h-g-l.B;15{6 s=h-g-l.B;n=s+(n-s)/5}15 0>n&&(l.1X===!1?n=0:n/=5);j.1k(a,n)}},2r:4(e){z(v.A("17-1m",l.L+"1v"),1e(x),"9"===l.q){6 i=!1,t=!0;b-=e,b>h-g-l.B?(b=h-g-l.B,l.N===!1&&(i=!0)):0>b&&(b=0);6 n=4(e){6 t=0;z(i||e&&(t=1),l.N)U(6 n=0,s=0;s<o.k&&(n+=1i(o.J(s).18())+l.B,p=s+t,!(n>=b));s++);15{6 a=b/((C+l.B)*l.K);p=1i(a)+t,b>=h-g-l.B&&a%1!==0&&p++}};e>=l.1r?(n(!1),t=!1):e<=-l.1r&&(n(!0),t=!1),a.q(t),j.1d()}15 e>=l.1r?a.1F():e<=-l.1r&&a.1j()},1U:4(){6 i=j;z(!w){v.8(".1O-1P").D("2o");6 t=0,n=0,s=!1;v.W("3b",4(i){Q g>h&&0!==h?!1:3G("7-2j"!==e(i.2Y).1M("1c")&&"7-3a"!==e(i.2Y).1M("1c")&&(t=l.E===!0?i.Z:i.11,s=!0,i.V?i.V():i.1D=!1,v.2z+=1,v.2z-=1,v.8(".1O-1P").13("2o").D("2w")))}),e(1p).W("3M",4(e){s&&(n=l.E===!0?e.Z:e.11,i.1H(n,t))}),e(1p).W("3N",4(a){z(s){v.8(".1O-1P").13("2w").D("2o"),s=!1,n=l.E===!0?a.Z:a.11;6 o=n-t;1I.2d(o)>=l.1r&&e(1p).W("1L.7",4(i){i.V?i.V():i.1D=!1,i.3P(),i.3Q(),e(1p).3R("1L.7")}),i.2r(o)}})}},1N:4(){6 e=j;z(w){6 i={},t={};v.W("3S",4(e){t=e.21.1W[0],i.11=e.21.1W[0].11,i.Z=e.21.1W[0].Z}),v.W("3U",4(n){z(g>h&&0!==h)Q!1;6 s=n.21;t=s.1W[0];6 a=1I.2d(t.11-i.11),o=1I.2d(t.Z-i.Z);l.E===!0?(3*o>a&&n.V(),e.1H(t.Z,i.Z)):(3*a>o&&n.V(),e.1H(t.11,i.11))}),v.W("3V",4(){z(g>h&&0!==h)Q!1;6 n;n=l.E===!0?t.Z-i.Z:t.11-i.11,e.2r(n)})}},2t:4(){6 e=j;e.2v(),e.1C(),j.Y()&&(l.1N===!0&&e.1N(),l.1U===!0&&e.1U()),e.H(),e.1S(),e.1J()}},n.2t(),y.1T=4(){y.2c(),l.E===!0?(g=l.1a>1?l.2g:o.28(),v.A("1q",g+"G")):g=v.2F(),l.P===!0&&"9"===l.q&&y.F(),y.2f(),"9"===l.q&&a.13("7-9"),"9"===l.q&&(y.20(),y.2e()),12(4(){"9"===l.q&&a.D("7-9")},3Y),l.H&&y.2m(),l.1Y===!0&&l.E===!1&&a.A("1q",o.J(p).28(!0)),l.1Y===!1&&("9"===l.q?l.E===!1&&n.1s(a,!1,!0):n.1s(a,!0,!0)),l.R===!0&&n.1d(),"9"===l.q&&n.9(),l.N===!1?o.k<=l.1a?v.8(".7-14").1K():v.8(".7-14").2s():y.1z(!1)<g&&0!==h?v.8(".7-14").1K():v.8(".7-14").2s()},a.1F=4(){z(p>0)l.2i.1g(j,a,p),p--,a.q(!1),l.R===!0&&n.1d();15 z(l.P===!0){z(l.2i.1g(j,a,p),"19"===l.q){6 e=f-1;p=1i(e/l.K)}a.q(!1),l.R===!0&&n.1d()}15 l.1B===!0&&(a.D("I-1G"),12(4(){a.13("I-1G")},27))},a.1j=4(){6 e=!0;z("9"===l.q){6 i=n.1w();e=i<h-g-l.B}p*l.K<f-l.K&&e?(l.2a.1g(j,a,p),p++,a.q(!1),l.R===!0&&n.1d()):l.P===!0?(l.2a.1g(j,a,p),p=0,a.q(!1),l.R===!0&&n.1d()):l.1B===!0&&(a.D("1b-1G"),12(4(){a.13("1b-1G")},27))},a.q=4(e){l.1Y===!0&&l.E===!1&&a.A("1q",o.J(p).28(!0)),u===!1&&("9"===l.q?n.Y()&&(a.D("7-9"),""!==l.L&&v.A("17-1m",l.L+"1v"),""!==l.1x&&v.A("17-2x-4",l.1x)):n.Y()&&(""!==l.L&&a.A("17-1m",l.L+"1v"),""!==l.1x&&a.A("17-2x-4",l.1x))),e||l.2G.1g(j,a,p),"9"===l.q?n.9():n.19(),12(4(){e||l.2H.1g(j,a,p)},l.L),u=!0},a.43=4(){1e(x),a.1j(),x=2C(4(){a.1j()},l.1Q)},a.1Q=4(){1e(x)},a.44=4(){y.1T()},a.45=4(){6 e=p;z(l.P){6 i=v.8(".7-9").k,t=a.8(".F.I").k;e=t-1>=p?i+(p-t):p>=i+t?p-i-t:p-t}Q e+1},a.46=4(){Q v.8(".7-9").k},a.47=4(e){p=l.P?e+a.8(".F.I").k-1:e,a.q(!1),l.R===!0&&n.1d()},12(4(){l.2D.1g(j,a)},10),e(1p).W("48 49",4(e){12(4(){e.V?e.V():e.1D=!1,y.1T()},4a)}),j}}(4b);', 62, 260, "||||function||var|ls|find|slide||||||||||this|length||||||mode|||||||||if|css|slideMargin||addClass|vertical|clone|px|pager|left|eq|slideMove|speed||autoWidth|active|loop|return|gallery|||for|preventDefault|on|parent|doCss|pageY||pageX|setTimeout|removeClass|action|else|li|transition|width|fade|item|right|class|slideThumb|clearInterval|0px|call|responsive|parseInt|goToNextSlide|move|children|duration|thumbMargin|null|window|height|swipeThreshold|setHeight|div|rtl|ms|slideValue|cssEasing|100|calWidth|margin|slideEndAnimatoin|auto|returnValue|translate3d|goToPrevSlide|end|touchMove|Math|keyPress|hide|click|attr|enableTouch|light|slider|pause|transform|controls|init|enableDrag|in|targetTouches|freeMove|adaptiveHeight|first|calSW|originalEvent|breakpoint|resetSlide|vThumbWidth|galleryMargin|document|400|outerHeight|easing|onBeforeNextSlide|remove|chbreakpoint|abs|sSW|calL|verticalHeight|settings|onBeforePrevSlide|prev|index|thumbItem|createPager|case|lsGrab|href|break|touchEnd|show|build|useCSS|initialStyle|lsGrabbing|timing|onBeforeStart|scrollLeft|documentElement|wrapper|setInterval|onSliderLoad|0ms|outerWidth|onBeforeSlide|onAfterSlide|disabled|prevHtml|fadeIn|fadeOut|calSlide|animate|relative|position|top|undefined|typeof|ul|webkit|keyCode|currentPagerPosition|hasOwnProperty|target|padding|middle|after|bottom|img|lightSlider|nextHtml|no||style||next|mousedown|html|src|thumb|data|none|display|pg|not|using|hasClass|load|prependTo|appendTo|outer|wrap|textarea|input|is|focus|lightslider|keyup|KhtmlTransition|50|switch|msTransition|OTransition|WebkitTransition|MozTransition|round|property|void|isEmptyObject|ontouchstart|el|extend|each|mousemove|mouseup|fn|stopImmediatePropagation|stopPropagation|off|touchstart|500|touchmove|touchend|2e3|linear|1e3|ease||strict|use|play|refresh|getCurrentSlideCount|getTotalSlideCount|goToSlide|resize|orientationchange|200|jQuery".split("|"), 0, {}));

jQuery(document).ready(function() {
	jQuery("body").on("click", ".jm-post-like", function(event) {
		event.preventDefault();
		heart = jQuery(this);
		post_id = heart.data("post_id");
		heart.html("<i class='fa fa-heart'></i>&nbsp;<i class='fa fa-cog fa-spin'></i>");
		jQuery.ajax({
			type: "post",
			url: ajax_var.url,
			data: "action=jm-post-like&nonce=" + ajax_var.nonce + "&jm_post_like=&post_id=" + post_id,
			success: function(count) {
				if (count.indexOf("already") !== -1) {
					var lecount = count.replace("already", "");
					if (lecount === "0") {
						lecount = "0"
					}
					heart.prop("title", "Like");
					heart.removeClass("liked");
					heart.html("<i class='fa fa-heart-o'></i>&nbsp;" + lecount)
				} else {
					heart.prop("title", "Unlike");
					heart.addClass("liked");
					heart.html("<i class='fa fa-heart'></i>&nbsp;" + count)
				}
			}
		})
	})
})

var IASCallbacks = function() {
		return this.list = [], this.fireStack = [], this.isFiring = !1, this.isDisabled = !1, this.fire = function(a) {
			var b = a[0],
				c = a[1],
				d = a[2];
			this.isFiring = !0;
			for (var e = 0, f = this.list.length; f > e; e++) {
				if (void 0 != this.list[e] && !1 === this.list[e].fn.apply(b, d)) {
					c.reject();
					break
				}
			}
			this.isFiring = !1, c.resolve(), this.fireStack.length && this.fire(this.fireStack.shift())
		}, this.inList = function(a, b) {
			b = b || 0;
			for (var c = b, d = this.list.length; d > c; c++) {
				if (this.list[c].fn === a || a.guid && this.list[c].fn.guid && a.guid === this.list[c].fn.guid) {
					return c
				}
			}
			return -1
		}, this
	};
IASCallbacks.prototype = {
	add: function(a, b) {
		var c = {
			fn: a,
			priority: b
		};
		b = b || 0;
		for (var d = 0, e = this.list.length; e > d; d++) {
			if (b > this.list[d].priority) {
				return this.list.splice(d, 0, c), this
			}
		}
		return this.list.push(c), this
	},
	remove: function(a) {
		for (var b = 0;
		(b = this.inList(a, b)) > -1;) {
			this.list.splice(b, 1)
		}
		return this
	},
	has: function(a) {
		return this.inList(a) > -1
	},
	fireWith: function(a, b) {
		var c = jQuery.Deferred();
		return this.isDisabled ? c.reject() : (b = b || [], b = [a, c, b.slice ? b.slice() : b], this.isFiring ? this.fireStack.push(b) : this.fire(b), c)
	},
	disable: function() {
		this.isDisabled = !0
	},
	enable: function() {
		this.isDisabled = !1
	}
}, function(a) {
	var b = -1,
		c = function(c, d) {
			return this.itemsContainerSelector = d.container, this.itemSelector = d.item, this.nextSelector = d.next, this.paginationSelector = d.pagination, this.$scrollContainer = c, this.$container = window === c.get(0) ? a(document) : c, this.defaultDelay = d.delay, this.negativeMargin = d.negativeMargin, this.nextUrl = null, this.isBound = !1, this.isPaused = !1, this.listeners = {
				next: new IASCallbacks,
				load: new IASCallbacks,
				loaded: new IASCallbacks,
				render: new IASCallbacks,
				rendered: new IASCallbacks,
				scroll: new IASCallbacks,
				noneLeft: new IASCallbacks,
				ready: new IASCallbacks
			}, this.extensions = [], this.scrollHandler = function() {
				if (this.isBound && !this.isPaused) {
					var a = this.getCurrentScrollOffset(this.$scrollContainer),
						c = this.getScrollThreshold();
					b != c && (this.fire("scroll", [a, c]), a >= c && this.next())
				}
			}, this.getItemsContainer = function() {
				return a(this.itemsContainerSelector)
			}, this.getLastItem = function() {
				return a(this.itemSelector, this.getItemsContainer().get(0)).last()
			}, this.getFirstItem = function() {
				return a(this.itemSelector, this.getItemsContainer().get(0)).first()
			}, this.getScrollThreshold = function(a) {
				var c;
				return a = a || this.negativeMargin, a = a >= 0 ? -1 * a : a, c = this.getLastItem(), 0 === c.length ? b : c.offset().top + c.height() + a
			}, this.getCurrentScrollOffset = function(a) {
				var b = 0,
					c = a.height();
				return b = window === a.get(0) ? a.scrollTop() : a.offset().top, (-1 != navigator.platform.indexOf("iPhone") || -1 != navigator.platform.indexOf("iPod")) && (c += 80), b + c
			}, this.getNextUrl = function(b) {
				return b = b || this.$container, a(this.nextSelector, b).last().attr("href")
			}, this.load = function(b, c, d) {
				var e, f, g = this,
					h = [],
					i = +new Date;
				d = d || this.defaultDelay;
				var j = {
					url: b
				};
				return g.fire("load", [j]), a.get(j.url, null, a.proxy(function(b) {
					e = a(this.itemsContainerSelector, b).eq(0), 0 === e.length && (e = a(b).filter(this.itemsContainerSelector).eq(0)), e && e.find(this.itemSelector).each(function() {
						h.push(this)
					}), g.fire("loaded", [b, h]), c && (f = +new Date - i, d > f ? setTimeout(function() {
						c.call(g, b, h)
					}, d - f) : c.call(g, b, h))
				}, g), "html")
			}, this.render = function(b, c) {
				var d = this,
					e = this.getLastItem(),
					f = 0,
					g = this.fire("render", [b]);
				g.done(function() {
					a(b).hide(), e.after(b), a(b).fadeIn(400, function() {
						++f < b.length || (d.fire("rendered", [b]), c && c())
					})
				})
			}, this.hidePagination = function() {
				this.paginationSelector && a(this.paginationSelector, this.$container).hide()
			}, this.restorePagination = function() {
				this.paginationSelector && a(this.paginationSelector, this.$container).show()
			}, this.throttle = function(b, c) {
				var d, e, f = 0;
				return d = function() {
					function a() {
						f = +new Date, b.apply(d, g)
					}
					var d = this,
						g = arguments,
						h = +new Date - f;
					e ? clearTimeout(e) : a(), h > c ? a() : e = setTimeout(a, c)
				}, a.guid && (d.guid = b.guid = b.guid || a.guid++), d
			}, this.fire = function(a, b) {
				return this.listeners[a].fireWith(this, b)
			}, this.pause = function() {
				this.isPaused = !0
			}, this.resume = function() {
				this.isPaused = !1
			}, this
		};
	c.prototype.initialize = function() {
		var a = !! ("onscroll" in this.$scrollContainer.get(0)),
			b = this.getCurrentScrollOffset(this.$scrollContainer),
			c = this.getScrollThreshold();
		return a ? (this.hidePagination(), this.bind(), this.fire("ready"), this.nextUrl = this.getNextUrl(), b >= c && this.next(), this) : !1
	}, c.prototype.reinitialize = function() {
		this.unbind(), this.initialize()
	}, c.prototype.bind = function() {
		if (!this.isBound) {
			this.$scrollContainer.on("scroll", a.proxy(this.throttle(this.scrollHandler, 150), this));
			for (var b = 0, c = this.extensions.length; c > b; b++) {
				this.extensions[b].bind(this)
			}
			this.isBound = !0, this.resume()
		}
	}, c.prototype.unbind = function() {
		if (this.isBound) {
			this.$scrollContainer.off("scroll", this.scrollHandler);
			for (var a = 0, b = this.extensions.length; b > a; a++) {
				"undefined" != typeof this.extensions[a].unbind && this.extensions[a].unbind(this)
			}
			this.isBound = !1
		}
	}, c.prototype.destroy = function() {
		this.unbind(), this.$scrollContainer.data("ias", null)
	}, c.prototype.on = function(b, c, d) {
		if ("undefined" == typeof this.listeners[b]) {
			throw new Error('There is no event called "' + b + '"')
		}
		return d = d || 0, this.listeners[b].add(a.proxy(c, this), d), this
	}, c.prototype.one = function(a, b) {
		var c = this,
			d = function() {
				c.off(a, b), c.off(a, d)
			};
		return this.on(a, b), this.on(a, d), this
	}, c.prototype.off = function(a, b) {
		if ("undefined" == typeof this.listeners[a]) {
			throw new Error('There is no event called "' + a + '"')
		}
		return this.listeners[a].remove(b), this
	}, c.prototype.next = function() {
		var a = this.nextUrl,
			b = this;
		if (this.pause(), !a) {
			return this.fire("noneLeft", [this.getLastItem()]), this.listeners.noneLeft.disable(), b.resume(), !1
		}
		var c = this.fire("next", [a]);
		return c.done(function() {
			b.load(a, function(a, c) {
				b.render(c, function() {
					b.nextUrl = b.getNextUrl(a), b.resume()
				})
			})
		}), c.fail(function() {
			b.resume()
		}), !0
	}, c.prototype.extension = function(a) {
		if ("undefined" == typeof a.bind) {
			throw new Error('Extension doesn\'t have required method "bind"')
		}
		return "undefined" != typeof a.initialize && a.initialize(this), this.extensions.push(a), this.reinitialize(), this
	}, a.ias = function() {
		var b = a(window);
		return b.ias.apply(b, arguments)
	}, a.fn.ias = function(b) {
		var d = Array.prototype.slice.call(arguments),
			e = this;
		return this.each(function() {
			var f = a(this),
				g = f.data("ias"),
				h = a.extend({}, a.fn.ias.defaults, f.data(), "object" == typeof b && b);
			if (g || (f.data("ias", g = new c(f, h)), a(document).ready(a.proxy(g.initialize, g))), "string" == typeof b) {
				if ("function" != typeof g[b]) {
					throw new Error('There is no method called "' + b + '"')
				}
				d.shift(), g[b].apply(g, d)
			}
			e = g
		}), e
	}, a.fn.ias.defaults = {
		item: ".item",
		container: ".listing",
		next: ".next",
		pagination: !1,
		delay: 600,
		negativeMargin: 10
	}
}(jQuery);
var IASHistoryExtension = function(a) {
		return a = jQuery.extend({}, this.defaults, a), this.ias = null, this.prevSelector = a.prev, this.prevUrl = null, this.listeners = {
			prev: new IASCallbacks
		}, this.onPageChange = function(a, b, c) {
			if (window.history && window.history.replaceState) {
				var d = history.state;
				history.replaceState(d, document.title, c)
			}
		}, this.onScroll = function(a) {
			var b = this.getScrollThresholdFirstItem();
			this.prevUrl && (a -= this.ias.$scrollContainer.height(), b >= a && this.prev())
		}, this.onReady = function() {
			var a = this.ias.getCurrentScrollOffset(this.ias.$scrollContainer),
				b = this.getScrollThresholdFirstItem();
			a -= this.ias.$scrollContainer.height(), b >= a && this.prev()
		}, this.getPrevUrl = function(a) {
			return a || (a = this.ias.$container), jQuery(this.prevSelector, a).last().attr("href")
		}, this.getScrollThresholdFirstItem = function() {
			var a;
			return a = this.ias.getFirstItem(), 0 === a.length ? -1 : a.offset().top
		}, this.renderBefore = function(a, b) {
			var c = this.ias,
				d = c.getFirstItem(),
				e = 0;
			c.fire("render", [a]), jQuery(a).hide(), d.before(a), jQuery(a).fadeIn(400, function() {
				++e < a.length || (c.fire("rendered", [a]), b && b())
			})
		}, this
	};
IASHistoryExtension.prototype.initialize = function(a) {
	var b = this;
	this.ias = a, jQuery.extend(a.listeners, this.listeners), a.prev = function() {
		return b.prev()
	}, this.prevUrl = this.getPrevUrl()
}, IASHistoryExtension.prototype.bind = function(a) {
	a.on("pageChange", jQuery.proxy(this.onPageChange, this)), a.on("scroll", jQuery.proxy(this.onScroll, this)), a.on("ready", jQuery.proxy(this.onReady, this))
}, IASHistoryExtension.prototype.unbind = function(a) {
	a.off("pageChange", this.onPageChange), a.off("scroll", this.onScroll), a.off("ready", this.onReady)
}, IASHistoryExtension.prototype.prev = function() {
	var a = this.prevUrl,
		b = this,
		c = this.ias;
	if (!a) {
		return !1
	}
	c.pause();
	var d = c.fire("prev", [a]);
	return d.done(function() {
		c.load(a, function(a, d) {
			b.renderBefore(d, function() {
				b.prevUrl = b.getPrevUrl(a), c.resume(), b.prevUrl && b.prev()
			})
		})
	}), d.fail(function() {
		c.resume()
	}), !0
}, IASHistoryExtension.prototype.defaults = {
	prev: ".prev"
};
var IASNoneLeftExtension = function(a) {
		return a = jQuery.extend({}, this.defaults, a), this.ias = null, this.uid = (new Date).getTime(), this.html = a.html.replace("{text}", a.text), this.showNoneLeft = function() {
			var a = jQuery(this.html).attr("id", "ias_noneleft_" + this.uid),
				b = this.ias.getLastItem();
			b.after(a), a.fadeIn()
		}, this
	};
IASNoneLeftExtension.prototype.bind = function(a) {
	this.ias = a, a.on("noneLeft", jQuery.proxy(this.showNoneLeft, this))
}, IASNoneLeftExtension.prototype.unbind = function(a) {
	a.off("noneLeft", this.showNoneLeft)
}, IASNoneLeftExtension.prototype.defaults = {
	text: "You reached the end.",
	html: '<div class="ias-noneleft" style="text-align: center;">{text}</div>'
};
var IASPagingExtension = function() {
		return this.ias = null, this.pagebreaks = [
			[0, document.location.toString()]
		], this.lastPageNum = 1, this.enabled = !0, this.listeners = {
			pageChange: new IASCallbacks
		}, this.onScroll = function(a) {
			if (this.enabled) {
				var b, c = this.ias,
					d = this.getCurrentPageNum(a),
					e = this.getCurrentPagebreak(a);
				this.lastPageNum !== d && (b = e[1], c.fire("pageChange", [d, a, b])), this.lastPageNum = d
			}
		}, this.onNext = function(a) {
			var b = this.ias.getCurrentScrollOffset(this.ias.$scrollContainer);
			this.pagebreaks.push([b, a]);
			var c = this.getCurrentPageNum(b) + 1;
			this.ias.fire("pageChange", [c, b, a]), this.lastPageNum = c
		}, this.onPrev = function(a) {
			var b = this,
				c = b.ias,
				d = c.getCurrentScrollOffset(c.$scrollContainer),
				e = d - c.$scrollContainer.height(),
				f = c.getFirstItem();
			this.enabled = !1, this.pagebreaks.unshift([0, a]), c.one("rendered", function() {
				for (var d = 1, g = b.pagebreaks.length; g > d; d++) {
					b.pagebreaks[d][0] = b.pagebreaks[d][0] + f.offset().top
				}
				var h = b.getCurrentPageNum(e) + 1;
				c.fire("pageChange", [h, e, a]), b.lastPageNum = h, b.enabled = !0
			})
		}, this
	};
IASPagingExtension.prototype.initialize = function(a) {
	this.ias = a, jQuery.extend(a.listeners, this.listeners)
}, IASPagingExtension.prototype.bind = function(a) {
	try {
		a.on("prev", jQuery.proxy(this.onPrev, this), this.priority)
	} catch (b) {}
	a.on("next", jQuery.proxy(this.onNext, this), this.priority), a.on("scroll", jQuery.proxy(this.onScroll, this), this.priority)
}, IASPagingExtension.prototype.unbind = function(a) {
	try {
		a.off("prev", this.onPrev)
	} catch (b) {}
	a.off("next", this.onNext), a.off("scroll", this.onScroll)
}, IASPagingExtension.prototype.getCurrentPageNum = function(a) {
	for (var b = this.pagebreaks.length - 1; b > 0; b--) {
		if (a > this.pagebreaks[b][0]) {
			return b + 1
		}
	}
	return 1
}, IASPagingExtension.prototype.getCurrentPagebreak = function(a) {
	for (var b = this.pagebreaks.length - 1; b >= 0; b--) {
		if (a > this.pagebreaks[b][0]) {
			return this.pagebreaks[b]
		}
	}
	return null
}, IASPagingExtension.prototype.priority = 500;
var IASSpinnerExtension = function(a) {
		return a = jQuery.extend({}, this.defaults, a), this.ias = null, this.uid = (new Date).getTime(), this.src = a.src, this.html = a.html.replace("{src}", this.src), this.showSpinner = function() {
			var a = this.getSpinner() || this.createSpinner(),
				b = this.ias.getLastItem();
			b.after(a), jQuery("body").append(a), a.fadeIn()
		}, this.showSpinnerBefore = function() {
			var a = this.getSpinner() || this.createSpinner(),
				b = this.ias.getFirstItem();
			b.before(a), a.fadeIn()
		}, this.removeSpinner = function() {
			this.hasSpinner() && this.getSpinner().remove()
		}, this.getSpinner = function() {
			var a = jQuery("#ias_spinner_" + this.uid);
			return a.length > 0 ? a : !1
		}, this.hasSpinner = function() {
			var a = jQuery("#ias_spinner_" + this.uid);
			return a.length > 0
		}, this.createSpinner = function() {
			var a = jQuery(this.html).attr("id", "ias_spinner_" + this.uid);
			return a.hide(), a
		}, this
	};
IASSpinnerExtension.prototype.bind = function(a) {
	this.ias = a, a.on("next", jQuery.proxy(this.showSpinner, this)), a.on("render", jQuery.proxy(this.removeSpinner, this));
	try {
		a.on("prev", jQuery.proxy(this.showSpinnerBefore, this))
	} catch (b) {}
}, IASSpinnerExtension.prototype.unbind = function(a) {
	a.off("next", this.showSpinner), a.off("render", this.removeSpinner);
	try {
		a.off("prev", this.showSpinnerBefore)
	} catch (b) {}
}, IASSpinnerExtension.prototype.defaults = {
	src: " ",
	html: '<div class="app-loading"><div class="loading-bar"></div></div>'
};
var IASTriggerExtension = function(a) {
		return a = jQuery.extend({}, this.defaults, a), this.ias = null, this.html = a.html.replace("{text}", a.text), this.htmlPrev = a.htmlPrev.replace("{text}", a.textPrev), this.enabled = !0, this.count = 0, this.offset = a.offset, this.$triggerNext = null, this.$triggerPrev = null, this.showTriggerNext = function() {
			if (!this.enabled) {
				return !0
			}
			if (!1 === this.offset || ++this.count < this.offset) {
				return !0
			}
			var a = this.$triggerNext || (this.$triggerNext = this.createTrigger(this.next, this.html)),
				b = this.ias.getLastItem();
			return b.after(a), a.fadeIn(), !1
		}, this.showTriggerPrev = function() {
			if (!this.enabled) {
				return !0
			}
			var a = this.$triggerPrev || (this.$triggerPrev = this.createTrigger(this.prev, this.htmlPrev)),
				b = this.ias.getFirstItem();
			return b.before(a), a.fadeIn(), !1
		}, this.onRendered = function() {
			this.enabled = !0
		}, this.createTrigger = function(a, b) {
			var c, d = (new Date).getTime();
			return b = b || this.html, c = jQuery(b).attr("id", "ias_trigger_" + d), c.hide(), c.on("click", jQuery.proxy(a, this)), c
		}, this
	};
IASTriggerExtension.prototype.bind = function(a) {
	this.ias = a, a.on("next", jQuery.proxy(this.showTriggerNext, this), this.priority), a.on("rendered", jQuery.proxy(this.onRendered, this), this.priority);
	try {
		a.on("prev", jQuery.proxy(this.showTriggerPrev, this), this.priority)
	} catch (b) {}
}, IASTriggerExtension.prototype.unbind = function(a) {
	a.off("next", this.showTriggerNext), a.off("rendered", this.onRendered);
	try {
		a.off("prev", this.showTriggerPrev)
	} catch (b) {}
}, IASTriggerExtension.prototype.next = function() {
	this.enabled = !1, this.ias.pause(), this.$triggerNext && (this.$triggerNext.remove(), this.$triggerNext = null), this.ias.next()
}, IASTriggerExtension.prototype.prev = function() {
	this.enabled = !1, this.ias.pause(), this.$triggerPrev && (this.$triggerPrev.remove(), this.$triggerPrev = null), this.ias.prev()
}, IASTriggerExtension.prototype.defaults = {
	text: "Load more items",
	html: '<div class="ias-trigger ias-trigger-next" style="text-align: center; cursor: pointer;"><a>{text}</a></div>',
	textPrev: "Load previous items",
	htmlPrev: '<div class="ias-trigger ias-trigger-prev" style="text-align: center; cursor: pointer;"><a>{text}</a></div>',
	offset: 0
}, IASTriggerExtension.prototype.priority = 1000;
(function($, sr) {
	var debounce = function(func, threshold, execAsap) {
			var timeout;
			return function debounced() {
				var obj = this,
					args = arguments;

				function delayed() {
					if (!execAsap) {
						func.apply(obj, args)
					}
					timeout = null
				}
				if (timeout) {
					clearTimeout(timeout)
				} else {
					if (execAsap) {
						func.apply(obj, args)
					}
				}
				timeout = setTimeout(delayed, threshold || 100)
			}
		};
	jQuery.fn[sr] = function(fn) {
		return fn ? this.bind("resize", debounce(fn)) : this.trigger(sr)
	}
})(jQuery, "smartresize");

function whichTransitionEvent() {
	var t, el = document.createElement("fakeelement");
	var transitions = {
		"transition": "transitionend",
		"OTransition": "oTransitionEnd",
		"MozTransition": "transitionend",
		"WebkitTransition": "webkitTransitionEnd"
	};
	for (t in transitions) {
		if (el.style[t] !== undefined) {
			return transitions[t]
		}
	}
}
var customTransitionEnd = whichTransitionEvent();
(function($) {
	var fbCount = 0;
	$.fn.fluidbox = function(opts) {
		var settings = $.extend(true, {
			viewportFill: 0.95,
			debounceResize: true,
			stackIndex: 1000,
			stackIndexDelta: 10,
			closeTrigger: [{
				selector: ".fluidbox-overlay",
				event: "click"
			}, {
				selector: "document",
				event: "keyup",
				keyCode: 27
			}],
			immediateOpen: false,
			loadingEle: true
		}, opts);
		var keyboardEvents = ["keyup", "keydown", "keypress"];
		if (settings.stackIndex < settings.stackIndexDelta) {
			settings.stackIndexDelta = settings.stackIndex
		}
		$fbOverlay = $("<div />", {
			"class": "fluidbox-overlay",
			css: {
				"z-index": settings.stackIndex
			}
		});
		var $fb = this,
			$w = $(window),
			vpRatio, funcCloseFb = function(selector) {
				$(selector + ".fluidbox-opened").trigger("click")
			},
			funcPositionFb = function($activeFb, customEvents) {
				var $img = $activeFb.find("img").first(),
					$ghost = $activeFb.find(".fluidbox-ghost"),
					$loader = $activeFb.find(".fluidbox-loader"),
					$wrap = $activeFb.find(".fluidbox-wrap"),
					$data = $activeFb.data(),
					fHeight = 0,
					fWidth = 0;
				$img.data().imgRatio = $data.natWidth / $data.natHeight;
				if (vpRatio > $img.data().imgRatio) {
					if ($data.natHeight < $w.height() * settings.viewportFill) {
						fHeight = $data.natHeight
					} else {
						fHeight = $w.height() * settings.viewportFill
					}
					$data.imgScale = fHeight / $img.height();
					$data.imgScaleY = $data.imgScale;
					$data.imgScaleX = $data.natWidth * (($img.height() * $data.imgScaleY) / $data.natHeight) / $img.width()
				} else {
					if ($data.natWidth < $w.width() * settings.viewportFill) {
						fWidth = $data.natWidth
					} else {
						fWidth = $w.width() * settings.viewportFill
					}
					$data.imgScale = fWidth / $img.width();
					$data.imgScaleX = $data.imgScale;
					$data.imgScaleY = $data.natHeight * (($img.width() * $data.imgScaleX) / $data.natWidth) / $img.height()
				}
				var offsetY = $w.scrollTop() - $img.offset().top + 0.5 * ($img.data("imgHeight") * ($img.data("imgScale") - 1)) + 0.5 * ($w.height() - $img.data("imgHeight") * $img.data("imgScale")),
					offsetX = 0.5 * ($img.data("imgWidth") * ($img.data("imgScale") - 1)) + 0.5 * ($w.width() - $img.data("imgWidth") * $img.data("imgScale")) - $img.offset().left,
					scale = parseInt($data.imgScaleX * 1000) / 1000 + "," + parseInt($data.imgScaleY * 1000) / 1000;
				$ghost.add($loader).css({
					"transform": "translate(" + parseInt(offsetX * 10) / 10 + "px," + parseInt(offsetY * 10) / 10 + "px) scale(" + scale + ")",
					top: $img.offset().top - $wrap.offset().top,
					left: $img.offset().left - $wrap.offset().left
				});
				$ghost.one(customTransitionEnd, function() {
					$.each(customEvents, function(i, customEvent) {
						$activeFb.trigger(customEvent)
					})
				})
			},
			funcCalc = function($fbItem) {
				vpRatio = $w.width() / $w.height();
				if ($fbItem.hasClass("fluidbox")) {
					var $img = $fbItem.find("img").first(),
						$ghost = $fbItem.find(".fluidbox-ghost"),
						$loader = $fbItem.find(".fluidbox-loader"),
						$wrap = $fbItem.find(".fluidbox-wrap"),
						data = $img.data();

					function imageProp() {
						data.imgWidth = $img.width();
						data.imgHeight = $img.height();
						data.imgRatio = $img.width() / $img.height();
						$ghost.add($loader).css({
							width: $img.width(),
							height: $img.height(),
							top: $img.offset().top - $wrap.offset().top + parseInt($img.css("borderTopWidth")) + parseInt($img.css("paddingTop")),
							left: $img.offset().left - $wrap.offset().left + parseInt($img.css("borderLeftWidth")) + parseInt($img.css("paddingLeft"))
						});
						if (vpRatio > data.imgRatio) {
							data.imgScale = $w.height() * settings.viewportFill / $img.height()
						} else {
							data.imgScale = $w.width() * settings.viewportFill / $img.width()
						}
					}
					imageProp();
					$img.load(imageProp)
				}
			},
			fbClickHandler = function(e) {
				if ($(this).hasClass("fluidbox")) {
					var $activeFb = $(this),
						$img = $(this).find("img").first(),
						$ghost = $(this).find(".fluidbox-ghost"),
						$loader = $(this).find(".fluidbox-loader"),
						$wrap = $(this).find(".fluidbox-wrap"),
						linkedImg = encodeURI($activeFb.attr("href")),
						timer = {};
					var fbOpen = function() {
							$activeFb.trigger("openstart");
							$activeFb.append('<div class="fluidbox-overlay" style="z-index: 1000; opacity: 1;"></div>').data("fluidbox-state", 1).removeClass("fluidbox-closed").addClass("fluidbox-opened");
							$(".rightbar").after('<div class="fluidbox-overlay" style="z-index: 0; opacity: 1;"></div>');
							$(".header").addClass("slide--up");
							$(".header").removeClass("slide--reset");
							if (timer["close"]) {
								window.clearTimeout(timer["close"])
							}
							timer["open"] = window.setTimeout(function() {
								$(".fluidbox-overlay").css({
									opacity: 1
								})
							}, 100);
							$(".fluidbox-wrap").css({
								zIndex: settings.stackIndex - settings.stackIndexDelta - 1
							});
							$wrap.css({
								"z-index": settings.stackIndex + settings.stackIndexDelta
							})
						},
						fbClose = function() {
							$activeFb.trigger("closestart");
							$activeFb.data("fluidbox-state", 0).removeClass("fluidbox-opened fluidbox-loaded fluidbox-loading").addClass("fluidbox-closed");
							if (timer["open"]) {
								window.clearTimeout(timer["open"])
							}
							timer["close"] = window.setTimeout(function() {
								$(".fluidbox-overlay").remove();
								$(".header").addClass("slide--reset");
								$(".header").removeClass("slide--up");
								$wrap.css({
									"z-index": settings.stackIndex - settings.stackIndexDelta
								})
							}, 10);
							$(".fluidbox-overlay").css({
								opacity: 0
							});
							$ghost.add($loader).css({
								"transform": "translate(0,0) scale(1,1)",
								opacity: 0,
								top: $img.offset().top - $wrap.offset().top + parseInt($img.css("borderTopWidth")) + parseInt($img.css("paddingTop")),
								left: $img.offset().left - $wrap.offset().left + parseInt($img.css("borderLeftWidth")) + parseInt($img.css("paddingLeft"))
							});
							$ghost.one(customTransitionEnd, function() {
								$activeFb.trigger("closeend")
							});
							$img.css({
								opacity: 1
							})
						};
					if ($(this).data("fluidbox-state") === 0 || !$(this).data("fluidbox-state")) {
						$activeFb.addClass("fluidbox-loading");
						$img.css({
							opacity: 0
						});
						$ghost.css({
							"background-image": "url(" + $img.attr("src") + ")",
							opacity: 1
						});
						if (settings.immediateOpen) {
							$activeFb.data("natWidth", $img[0].naturalWidth).data("natHeight", $img[0].naturalHeight);
							fbOpen();
							funcPositionFb($activeFb, ["openend"]);
							$("<img />", {
								src: linkedImg
							}).load(function() {
								$activeFb.trigger("imageloaddone").trigger("delayedloaddone").removeClass("fluidbox-loading").addClass("fluidbox-loaded").data("natWidth", $(this)[0].naturalWidth).data("natHeight", $(this)[0].naturalHeight);
								$ghost.css({
									"background-image": "url(" + linkedImg + ")"
								});
								funcPositionFb($activeFb, ["delayedreposdone"])
							}).error(function() {
								$activeFb.trigger("imageloadfail");
								fbClose()
							})
						} else {
							$("<img />", {
								src: linkedImg
							}).load(function() {
								$activeFb.trigger("imageloaddone").removeClass("fluidbox-loading").addClass("fluidbox-loaded").data("natWidth", $(this)[0].naturalWidth).data("natHeight", $(this)[0].naturalHeight);
								settings.immediateOpen = true;
								$ghost.css({
									"background-image": "url(" + linkedImg + ")"
								});
								fbOpen();
								funcPositionFb($activeFb, ["openend"])
							}).error(function() {
								$activeFb.trigger("imageloadfail");
								fbClose()
							})
						}
					} else {
						fbClose()
					}
					e.preventDefault()
				}
			};
		var funcResize = function(selectorChoice) {
				if (!selectorChoice) {
					$fb.each(function() {
						funcCalc($(this))
					})
				} else {
					funcCalc(selectorChoice)
				}
				var $activeFb = $("a.fluidbox.fluidbox-opened");
				if ($activeFb.length > 0) {
					funcPositionFb($activeFb, ["resizeend"])
				}
			};
		if (settings.debounceResize) {
			$(window).smartresize(function() {
				funcResize()
			})
		} else {
			$(window).resize(function() {
				funcResize()
			})
		}
		$fb.each(function(i) {
			if ($(this).is("a") && $(this).children().length === 1 && $(this).children().is("img") && $(this).css("display") !== "none" && $(this).parents().css("display") !== "none") {
				var $fbInnerWrap = $("<div />", {
					"class": "fluidbox-wrap",
					css: {
						"z-index": settings.stackIndex - settings.stackIndexDelta
					}
				});
				var $fbLoader = $("<div />", {
					"class": "fluidbox-loader"
				});
				fbCount += 1;
				var $fbItem = $(this);
				$fbItem.addClass("fluidbox fluidbox-closed").attr("id", "fluidbox-" + fbCount).wrapInner($fbInnerWrap).find("img").first().css({
					opacity: 1
				}).after('<div class="fluidbox-ghost" />').each(function() {
					var $img = $(this);
					if ($img.width() > 0 && $img.height() > 0) {
						funcCalc($fbItem);
						$fbItem.click(fbClickHandler)
					} else {
						$img.load(function() {
							funcCalc($fbItem);
							$fbItem.click(fbClickHandler);
							$fbItem.trigger("thumbloaddone")
						}).error(function() {
							$fbItem.trigger("thumbloadfail")
						})
					}
				});
				if (settings.loadingEle) {
					$fbItem.find(".fluidbox-ghost").after($fbLoader)
				}
				$(this).on("recompute", function() {
					funcResize($(this));
					$(this).trigger("recomputeend")
				});
				var selector = "#fluidbox-" + fbCount;
				if (settings.closeTrigger) {
					$.each(settings.closeTrigger, function(i) {
						var trigger = settings.closeTrigger[i];
						if (trigger.selector != "window") {
							if (trigger.selector == "document") {
								if (trigger.keyCode && keyboardEvents.indexOf(trigger.event) > -1) {
									$(document).on(trigger.event, function(e) {
										if (e.keyCode == trigger.keyCode) {
											funcCloseFb(selector)
										}
									})
								} else {
									$(document).on(trigger.event, selector, function() {
										funcCloseFb(selector)
									})
								}
							}
						} else {
							$w.on(trigger.event, function() {
								funcCloseFb(selector)
							})
						}
					})
				}
			}
		});
		return $fb
	}
})(jQuery);
(function(factory) {
	if (typeof define === "function" && define.amd) {
		define(["jquery"], factory)
	} else {
		if (typeof exports === "object") {
			module.exports = factory(require("jquery"))
		} else {
			factory(jQuery)
		}
	}
}(function($) {
	var pluses = /\+/g;

	function encode(s) {
		return config.raw ? s : encodeURIComponent(s)
	}
	function decode(s) {
		return config.raw ? s : decodeURIComponent(s)
	}
	function stringifyCookieValue(value) {
		return encode(config.json ? JSON.stringify(value) : String(value))
	}
	function parseCookieValue(s) {
		if (s.indexOf('"') === 0) {
			s = s.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\")
		}
		try {
			s = decodeURIComponent(s.replace(pluses, " "));
			return config.json ? JSON.parse(s) : s
		} catch (e) {}
	}
	function read(s, converter) {
		var value = config.raw ? s : parseCookieValue(s);
		return $.isFunction(converter) ? converter(value) : value
	}
	var config = $.cookie = function(key, value, options) {
			if (arguments.length > 1 && !$.isFunction(value)) {
				options = $.extend({}, config.defaults, options);
				if (typeof options.expires === "number") {
					var days = options.expires,
						t = options.expires = new Date();
					t.setMilliseconds(t.getMilliseconds() + days * 86400000)
				}
				return (document.cookie = [encode(key), "=", stringifyCookieValue(value), options.expires ? "; expires=" + options.expires.toUTCString() : "", options.path ? "; path=" + options.path : "", options.domain ? "; domain=" + options.domain : "", options.secure ? "; secure" : ""].join(""))
			}
			var result = key ? undefined : {},
				cookies = document.cookie ? document.cookie.split("; ") : [],
				i = 0,
				l = cookies.length;
			for (; i < l; i++) {
				var parts = cookies[i].split("="),
					name = decode(parts.shift()),
					cookie = parts.join("=");
				if (key === name) {
					result = read(cookie, value);
					break
				}
				if (!key && (cookie = read(cookie)) !== undefined) {
					result[name] = cookie
				}
			}
			return result
		};
	config.defaults = {};
	$.removeCookie = function(key, options) {
		$.cookie(key, "", $.extend({}, options, {
			expires: -1
		}));
		return !$.cookie(key)
	}
}));
!
function(t, e) {
	"function" == typeof define && define.amd ? define(function() {
		return e(t)
	}) : "object" == typeof exports ? module.exports = e : t.echo = e(t)
}(this, function(t) {
	var e, n, o, r, c, a = {},
		u = function() {},
		d = function(t) {
			return null === t.offsetParent
		},
		i = function(t, e) {
			if (d(t)) {
				return !1
			}
			var n = t.getBoundingClientRect();
			return n.right >= e.l && n.bottom >= e.t && n.left <= e.r && n.top <= e.b
		},
		l = function() {
			(r || !n) && (clearTimeout(n), n = setTimeout(function() {
				a.render(), n = null
			}, o))
		};
	return a.init = function(n) {
		n = n || {};
		var d = n.offset || 0,
			i = n.offsetVertical || d,
			f = n.offsetHorizontal || d,
			s = function(t, e) {
				return parseInt(t || e, 10)
			};
		e = {
			t: s(n.offsetTop, i),
			b: s(n.offsetBottom, i),
			l: s(n.offsetLeft, f),
			r: s(n.offsetRight, f)
		}, o = s(n.throttle, 250), r = n.debounce !== !1, c = !! n.unload, u = n.callback || u, a.render(), document.addEventListener ? (t.addEventListener("scroll", l, !1), t.addEventListener("load", l, !1)) : (t.attachEvent("onscroll", l), t.attachEvent("onload", l))
	}, a.render = function() {
		for (var n, o, r = document.querySelectorAll("img[data-echo], [data-echo-background]"), d = r.length, l = {
			l: 0 - e.l,
			t: 0 - e.t,
			b: (t.innerHeight || document.documentElement.clientHeight) + e.b,
			r: (t.innerWidth || document.documentElement.clientWidth) + e.r
		}, f = 0; d > f; f++) {
			o = r[f], i(o, l) ? (c && o.setAttribute("data-echo-placeholder", o.src), null !== o.getAttribute("data-echo-background") ? o.style.backgroundImage = "url(" + o.getAttribute("data-echo-background") + ")" : o.src = o.getAttribute("data-echo"), c || (o.removeAttribute("data-echo"), o.removeAttribute("data-echo-background")), u(o, "load")) : c && (n = o.getAttribute("data-echo-placeholder")) && (null !== o.getAttribute("data-echo-background") ? o.style.backgroundImage = "url(" + n + ")" : o.src = n, o.removeAttribute("data-echo-placeholder"), u(o, "unload"))
		}
		d || a.detach()
	}, a.detach = function() {
		document.removeEventListener ? t.removeEventListener("scroll", l) : t.detachEvent("onscroll", l), clearTimeout(n)
	}, a
});

(function(window, document, $){
	function extend(target, source) {
		for (var prop in source) {
			target[prop] = (typeof source[prop] === 'object') ? extend(target[prop], source[prop]) : source[prop];
		}
		return target;
	}

	window.MouseTooltip = {
		init: function(opts) {
			self.opts = extend({
				cssTransforms: false,
				tooltipOffset: { x: 10, y: 10 },
				tooltipClass: 'mouse-tooltip',
				tooltipId: 'mouse-tooltip',
				contentAttr: 'data-tooltip',
				contentClass: 'with-tooltip',
				mouseActionsHandler: self.onMouseAction
			}, opts || {});

			$('#' + self.opts.tooltipId).remove();
			self.$tooltip = $('body').append('<div id="' + self.opts.tooltipId + '" class="' + self.opts.tooltipClass + '"></div>').find('#' + self.opts.tooltipId).first();
			self.hide();

			if (self.opts.mouseActionsHandler)
				$('body').on('mouseover click mouseout', '.' + self.opts.contentClass, self.opts.mouseActionsHandler);
		},
		content: function(html) {
			self.$tooltip.html(html);
		},
		show: function(html) {
			self.content(html);
			self.$tooltip.removeClass(self.opts.tooltipClass + '--hidden');
			$(document).on('mousemove.tooltip', self._stickToMouse);
		},
		hide: function() {
			self.$tooltip.addClass(self.opts.tooltipClass + '--hidden');
			$(document).off('mousemove.tooltip');
		},
		_stickToMouse: function(e) {
			xOffset = self.opts.tooltipOffset.x;
			yOffset = self.opts.tooltipOffset.y;
			var win = $(window),
				ttWidth = self.$tooltip.outerWidth(),
				ttHeight = self.$tooltip.outerHeight(),
				mouseX = e.pageX,
				mouseY = e.pageY,
				ttLeft = mouseX,
				ttTop = mouseY;
			if ((mouseX + ttWidth + xOffset) > win.width()) {
				ttLeft = mouseX - ttWidth;
				xOffset = xOffset * -1;
			}
			if ((mouseY + ttHeight + yOffset) > win.height()) {
				ttTop = mouseY - ttHeight;
				yOffset = yOffset * -1;
			}
			ttLeft = ttLeft + xOffset + "px";
			ttTop = ttTop + yOffset + "px";
			var pos = {};
			if (self.opts.cssTransforms && window.Modernizr !== undefined && (Modernizr.csstransforms3d || Modernizr.csstransforms)) {
				pos[Modernizr.prefixed('transform')] = "translateX(" + ttLeft + ") translateY(" + ttTop + ")";
				pos['transform'] = "translateX(" + ttLeft + ") translateY(" + ttTop + ")";
				if (Modernizr.csstransforms3d) {
					pos[Modernizr.prefixed('transform')] += " translateZ(0)";
					pos['transform'] += " translateZ(0)";
				}
			} else
				pos = { left: ttLeft, top: ttTop };
			self.$tooltip.css(pos);
		},
		onMouseAction: function(e) {
			$target = $(e.currentTarget);
			var content = $target.attr(self.opts.contentAttr) || $target.find('[' + self.opts.contentAttr + ']').attr(self.opts.contentAttr);
			if (e.type == "mouseover")
				self.show( content );
			else if (e.type == "click")
				self.content( content );
			else
				self.hide();
		}
	};
	var self = window.MouseTooltip;
})(window, document, jQuery);
/* @license minigrid v1.6.1 - minimal cascading grid layout http://alves.im/minigrid */
!function(t){"use strict";function e(t,e,n,o,r){var i=Array.prototype.forEach,f=t instanceof Node?t:document.querySelector(t);if(!f)return!1;var s=f.querySelectorAll(e);if(0===s.length)return!1;n="number"==typeof n&&isFinite(n)&&Math.floor(n)===n?n:6,f.style.width="";var u=f.getBoundingClientRect().width,l=s[0].getBoundingClientRect().width+n,a=Math.max(Math.floor((u-n)/l),1),c=0;u=l*a+n+"px",f.style.width=u,f.style.position="relative";for(var d=[],p=[],h=0;a>h;h++)p.push(h*l+n),d.push(n);i.call(s,function(t){var e=d.slice(0).sort(function(t,e){return t-e}).shift();e=d.indexOf(e);var r=p[e],f=d[e],s=["webkitTransform","MozTransform","msTransform","OTransform","transform"];return t.style.position="absolute",o||i.call(s,function(e){t.style[e]="translate3D("+r+"px,"+f+"px,0)"}),d[e]+=t.getBoundingClientRect().height+n,c+=1,o?o(t,r,f,c):void 0});var m=d.slice(0).sort(function(t,e){return t-e}).pop();f.style.height=m+"px","function"==typeof r&&r(s)}"function"==typeof define&&define.amd?define(function(){return e}):"undefined"!=typeof module&&module.exports?module.exports=e:t.minigrid=e}(this);