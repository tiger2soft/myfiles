<form method="get" class="search-form" action="/" >
		<input class="input-medium search-query" name="s" type="text" value="<?php echo esc_attr( get_search_query() ); ?>" placeholder="<?php _e( '搜索', 'jianshu' ); ?>">
</form>
