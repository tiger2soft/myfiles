<?php get_header(); ?>

<div id="main"> 
  <?php get_template_part( 'content'); ?>
</div>
<?php get_footer();?>
