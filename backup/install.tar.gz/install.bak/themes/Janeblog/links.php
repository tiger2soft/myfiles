<?php $options = (ClassicOptions::getOptions()); ?>
<!--友情链接-->
<div class="links w760">
  <h3 class="h3">友情链接：</h3>
  <p><?php echo($options['jane_links']);?>  </p>
</div>